<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {
	
	//default valiables	
	private $status=false;
	private $fail_result=false;
	private $addition_info='';
	private $result_info="";
	private $result_array=array();

   
    
	public function __construct()
	{ 
	      // Call the CI_Model constructor
	      parent::__construct();
	      											
	} 

 #--------------------------------------------------
    private function reset_defaults()
    {

		$this->status=false;
		$this->fail_result=false;
		$this->addition_info='';
		$this->result_info="";
		$this->result_array=array();
    } 

	public function index() // sign_in
	{
		// redirect all unlogined_users to home when trying to access this page
    	if(isset($_SESSION['login']) && $_SESSION['login']=="login" )
    	{
    		redirect(base_url(),"refresh");
    	}

		$this->load->view('page-signin');
	}

	public function register_taxpayer()
	{

		$this->load->view('page_register_taxpayer');
	}

	public function sign_in_form()
	{
		
		//reset default variable
		$this->reset_defaults();

		//include libraries
		$this->load->library('form_validation');
		$this->load->library('MY_Form_Validation');
		
		//validation configurations
		
 		$validationRules = array(
			       'sign_in'=> array( array(
							                'field' => 'password',
							                'label' => 'Password',
							                'rules' => 'required',
							                'errors' => array(
									                        'required' => 'Confirm Password is required',
							                				),
							       		 ),
							        array(
							                'field' => 'email',
							                'label' => 'Email',
							                'rules' => 'required|valid_email',
							                'errors' => array(
									                        'required' => 'Email is required',
									                        'valid_email' => 'Provide a valid email',
							                				),		                
							        	),
			        			),
				);

 		//validate
        $this->form_validation->set_rules($validationRules['sign_in']);
        $this->form_validation->set_error_delimiters('', '');
	    if ($this->form_validation->run() == FALSE)
        {
                $this->fail_result=true;
       			$this->addition_info='validation error';
       			$this->result_info="Sorry An error Occurred";
       			// control the error messsages
       			$this->result_array= $this->form_validation->error_array();
       			
        }

		echo "<pre>";
		#print_r($this->input->post());
		#print_r($this->result_array);
        
	   // flesh load	
       if(!$this->fail_result)
       {

       	    $url = "https://www.mra.mw/sandbox/programming/challenge/webservice/auth/login";

			// Setup request to send json via POST
			$data = array(
			    'Email' => $this->input->post('email'),
			    'Password' => $this->input->post('password')
			);
	
			$resp= $this->curl($url,$data);

       		#print_r($resp);

            if($resp['Authenticated']==1)
             {
 	          //set session
              	$_SESSION["Username"] = $resp['UserDetails']['Username'];
	            $_SESSION["FirstName"] = $resp['UserDetails']['Firstname'];
	            $_SESSION["LastName"] = $resp['UserDetails']['LastName'];
	            $_SESSION["email"] = $resp['UserDetails']['Email'];
              	$_SESSION['login']=true;
              	$_SESSION['expire'] = time()+3*60*60;

             	redirect(base_url()."home",$resp);
             }
             else
             {
             	$this->load->view('page-signin',$resp);
             }

       }
    }

	public function register_taxpayer_form()
	{
		
		//reset default variable
		$this->reset_defaults();

		//include libraries
		$this->load->library('form_validation');
		$this->load->library('MY_Form_Validation');
		
		//validation configurations
		
 		$validationRules = array(
			       'register'=> array( array(
							                'field' => 'TPIN',
							                'label' => 'TPIN',
							                'rules' => 'required|max_length[30]',
							                'errors' => array(
									                        'required' => 'TPIN is required',
									                        'max_length' => 'Must not exceed 30 Characters long',
							                				),
							       		 ),
							        array(
							                'field' => 'Email',
							                'label' => 'Email',
							                'rules' => 'required|valid_email',
							                'errors' => array(
									                        'required' => 'Email is required',
									                        'valid_email' => 'Provide a valid email',
							                				),		                
							        	),
							        array(
							                'field' => 'Username',
							                'label' => 'Username',
							                'rules' => 'required|max_length[15]',
							                'errors' => array(
									                        'required' => 'Username is required',
									                        'max_length' => 'Must not exceed 24 Characters',
							                				),	                
							        	),
							        array(
							                'field' => 'TradingName',
							                'label' => 'TradingName',
							                'rules' => 'required|max_length[15]',
							                'errors' => array(
									                        'required' => 'Trading Name is required',
									                        'max_length' => 'Must not exceed 24 Characters',
							                				),	                
							        	),
							        array(
							                'field' => 'BusinessCertificateNumber',
							                'label' => 'BusinessCertificateNumber',
							                'rules' => 'required|max_length[15]',
							                'errors' => array(
									                        'required' => 'Business Certificate Number is required',
									                        'max_length' => 'Must not exceed 24 Characters',
							                				),	                
							        	),
							        array(
							                'field' => 'BusinessRegistrationDate',
							                'label' => 'BusinessRegistrationDate',
							                'rules' => 'required|max_length[15]',
							                'errors' => array(
									                        'required' => 'Business Registration Date is required',
									                        'max_length' => 'Must not exceed 24 Characters',
							                				),	                
							        	),
							        array(
							                'field' => 'PhysicalLocation',
							                'label' => 'PhysicalLocation',
							                'rules' => 'required|max_length[15]',
							                'errors' => array(
									                        'required' => 'Physical Location is required',
									                        'max_length' => 'Must not exceed 24 Characters',
							                				),	                
							        	),
							        array(
							                'field' => 'MobileNumber',
							                'label' => 'MobileNumber',
							                'rules' => 'required|max_length[15]',
							                'errors' => array(
									                        'required' => 'Mobile Number is required',
									                        'max_length' => 'Must not exceed 24 Characters',
							                				),	                
							        	),
							        
			        			),
				);

 		//validate
        $this->form_validation->set_rules($validationRules['register']);
        $this->form_validation->set_error_delimiters('', '');
	    if ($this->form_validation->run() == FALSE)
        {
                $this->fail_result=true;
       			$this->addition_info='validation error';
       			$this->result_info="Sorry An error Occurred";
       			// control the error messsages
       			$this->result_array= $this->form_validation->error_array();
       			
        }

		#secho "<pre>";
		#print_r($this->input->post());
		#print_r($this->result_array);
        
	   // flesh load	
       if(!$this->fail_result)
       {

     
		#print_r($this->input->post());
       	    
            
       	    $url = "https://www.mra.mw/sandbox/programming/challenge/webservice/Taxpayers/add";

			// Setup request to send json via POST
			$data = array(
	                         'Username'=>$this->input->post('Username'),
	                         'Email'=>$this->input->post('Email'),
	                         'MobileNumber'=>$this->input->post('MobileNumber'),
	                         'TPIN'=>$this->input->post('TPIN'),
	                         'PhysicalLocation'=>$this->input->post('PhysicalLocation'),
	                         'TradingName'=>$this->input->post('TradingName'),
	                         'BusinessCertificateNumber'=>$this->input->post('BusinessCertificateNumber'),
	                         'BusinessRegistrationDate'=>$this->input->post('BusinessRegistrationDate'),
	                       );
			$resp= $this->curl($url,$data);

       		print_r($resp);
       		if($resp['ResultCode']==1)
             {
       	    
             	redirect(base_url().'home');
             }else
             {
             	redirect(base_url().'register_taxpayer',$resp);
             }

       }else
             {
             	redirect(base_url().'register_taxpayer',$result_array);
             }
    }


	public function sign_out()
	{
	   
	    // redirect all unlogined_users to home when trying to access this page
    	if(!isset($_SESSION['login']) || $_SESSION['login']!="login" )
    	{
    		redirect(base_url()."signin","refresh");
    	}

    	 $url = "https://www.mra.mw/sandbox/programming/challenge/auth/logout";

			// Setup request to send json via POST
			$data = array(
			    'Email' => "achipalamwazani@yahoo.co.uk",
			);


			$resp= $this->curl($url,$data);

       		#print_r($resp);

			session_destroy();
            session_write_close();
            session_unset();
            $_SESSION=array();
	       
	        $this->load->view('page-signin',$resp);
	                
	       
	} 

	private function curl($url,$data) {
			


			
			$curl = curl_init($url);
			curl_setopt($curl, CURLOPT_URL, $url);
			curl_setopt($curl, CURLOPT_POST, true);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

			$headers = array(
			   "Content-Type: application/json",
			   "apikey: 3fdb48c5-336b-47f9-87e4-ae73b8036a1c",
			   "candidateid: achipalamwazani@yahoo.co.uk"
			);
			curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
			
			$data = json_encode($data);

			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

			//for debug only!
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

			$resp = curl_exec($curl);
			curl_close($curl);
			
			print_r($data);
			// Will dump a beauty json :3
			$resp=json_decode($resp, true);
			#var_dump($resp);
			
			#print_r($resp);

			return $resp;
	}


}
