<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct()
	{ 
	      // Call the CI_Model constructor
	      parent::__construct();

	      	// redirect all unlogined_users to home when trying to access this page
	    	if(!isset($_SESSION['login']) || $_SESSION['login']!="login")
	    	{
	    		redirect(base_url().'signin',"refresh");
	    	}
	      											
	} 

	public function index()
	{
			$url = "https://www.mra.mw/sandbox/programming/challenge/webservice/Taxpayers/getAll";
			$curl = curl_init($url);
			curl_setopt($curl, CURLOPT_URL, $url);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

			$headers = array(
			   "Accept: application/json",
			   "Content-Type: application/json",
			   "apikey: 3fdb48c5-336b-47f9-87e4-ae73b8036a1c",
			   "candidateid: achipalamwazani@yahoo.co.uk"
			);
			curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
			
			//for debug only!
			curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

			$resp = curl_exec($curl);
			curl_close($curl);
			
			// Will dump a beauty json :3
			$resp=json_decode($resp, true);
			#var_dump($resp);
			
			#print_r($resp);
		   

			// Setup request to send json via POST
			$data = array();
			$data = json_encode($data);

       		#print_r($resp);

            /*if($resp['Authenticated']==1)
             {
             }
             else
             {
             
             }*/

		$this->load->view('dashboard-two',$resp);
	}

	
}

